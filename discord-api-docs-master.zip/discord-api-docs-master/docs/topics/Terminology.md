# Terminology

## Guild(s)

A collection of users and channels, often referred to in the UI as a server.